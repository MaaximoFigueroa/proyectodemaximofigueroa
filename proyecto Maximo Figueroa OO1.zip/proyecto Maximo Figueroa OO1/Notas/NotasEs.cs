﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notas
{
    [Table("NotasEstudiantes")]
    public class NotasEs
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id_ { get; set; }

        [Required]
        [MaxLength(50)]
        public string? Nombre_ { get; set; }

        [Required]
        [MaxLength(50)]
        public string? Apellido_ { get; set; }

        [Range(0, 100)]
        public double Notas_ { get; set; }

        public bool Firma_ { get; set; }

        public DateTime FechaEvaluacion_ { get; set; }
    }
}
