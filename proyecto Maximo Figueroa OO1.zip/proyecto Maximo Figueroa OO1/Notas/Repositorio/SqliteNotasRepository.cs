﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Data.Sqlite;

namespace Notas.Repositorio
{
    internal class SqliteNotasRepository(SqliteConnection sqliteConnection) : IRepositorioNotas
    {
        private SqliteConnection _connection = sqliteConnection;

        public List<NotasEstudiantes> ObtenerNotas()
        {
            using var command = _connection.CreateCommand();
            var notas = new List<NotasEstudiantes>();

            command.CommandText = @"
                    SELECT
                        Id,
                        Nombre,
                        Apellido,
                        Notas,
                        Firma,
                        FechaEvaluacion
                    FROM
                        NotasEstudiantes;
                ";

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                notas.Add(new NotasEstudiantes(
                    reader.GetInt64(0),
                    reader.GetString(1),
                    reader.GetString(2),
                    reader.GetDouble(3),
                    reader.GetBoolean(4),
                    reader.GetDateTime(5)
                ));
            }

            return notas;
        }

        public void AgregarNota(NotasEstudiantes nota)
        {
            using var command = _connection.CreateCommand();
            command.CommandText = @"
                    INSERT INTO
                    NotasEstudiantes(Nombre, Apellido, Notas, Firma, FechaEvaluacion)
                    VALUES(@nombre, @apellido, @nota, @firma, @fecha);
                ";

            command.Parameters.AddWithValue("@nombre", nota.Nombre);
            command.Parameters.AddWithValue("@apellido", nota.Apellido);
            command.Parameters.AddWithValue("@nota", nota.Notas);
            command.Parameters.AddWithValue("@firma", nota.Firma);
            command.Parameters.AddWithValue("@fecha", nota.FechaEvaluacion);
            command.ExecuteNonQuery();

            using var idCommand = _connection.CreateCommand();
            idCommand.CommandText = "SELECT last_insert_rowid();";
            nota.Id = (long)idCommand.ExecuteScalar();
        }

        public bool ActualizarNota(NotasEstudiantes nota)
        {
            using var command = _connection.CreateCommand();
            command.CommandText = @"
                    UPDATE NotasEstudiantes
                    SET
                        Nombre = @nombre,
                        Apellido = @apellido,
                        Notas = @nota,
                        Firma = @firma,
                        FechaEvaluacion = @fecha
                    WHERE
                        Id = @id;
                ";

            command.Parameters.AddWithValue("@nombre", nota.Nombre);
            command.Parameters.AddWithValue("@apellido", nota.Apellido);
            command.Parameters.AddWithValue("@nota", nota.Notas);
            command.Parameters.AddWithValue("@firma", nota.Firma);
            command.Parameters.AddWithValue("@fecha", nota.FechaEvaluacion);
            command.Parameters.AddWithValue("@id", nota.Id);
            return command.ExecuteNonQuery() > 0;
        }

        public bool EliminarNota(NotasEstudiantes nota)
        {
            using var command = _connection.CreateCommand();
            command.CommandText = @"
                    DELETE FROM NotasEstudiantes
                    WHERE Id = @id;
                ";
            command.Parameters.AddWithValue("@id", nota.Id);
            return command.ExecuteNonQuery() > 0;
        }
    }
}
