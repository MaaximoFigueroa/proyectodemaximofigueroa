﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notas.Repositorio
{
    internal interface IRepositorioNotas
    {
        List<NotasEstudiantes> ObtenerNotas();

        void AgregarNota(NotasEstudiantes nota);
        bool ActualizarNota(NotasEstudiantes nota);
        bool EliminarNota(NotasEstudiantes nota);
        
    }
}
