﻿
namespace Notas.Repositorio
{
    internal class RepositorioNotas : IRepositorioNotas
    {
        public List<NotasEstudiantes> ObtenerNotas()
        {
            using var context = new NotasContext();
            return context.notas.ToList();
        }

        public void AgregarNota(NotasEstudiantes nota)
        {
            using var context = new NotasContext();
            context.notas.Add(nota);
            context.SaveChanges();

        }

        public bool ActualizarNota(NotasEstudiantes nota)
        {
            using var context = new NotasContext();
            context.notas.Update(nota);
            return context.SaveChanges() > 0;
        }

        public bool EliminarNota(NotasEstudiantes nota)
        {
            using var context = new NotasContext();
            context.notas.Remove(nota);
            return context.SaveChanges() > 0;
        }

    }
}
