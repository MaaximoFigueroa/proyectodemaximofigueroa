﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace Notas
{
    internal class Connection
    {
        private static SqliteConnection? _connection;

        private Connection() 
        {  
        }

        public static SqliteConnection GetConnection()
        {
            if (_connection == null)
            {
                _connection = new SqliteConnection("Data Source=notas.db");
                _connection.Open();

                using var createTableCommand = _connection.CreateCommand();
                createTableCommand.CommandText = @"
                    CREATE TABLE IF NOT EXISTS NotasEstudiantes (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Nombre TEXT NOT NULL,
                        Apellido TEXT NOT NULL,
                        Notas REAL NOT NULL,
                        Firma INTEGER NOT NULL DEFAULT 0,
                        FechaEvaluacion TEXT NOT NULL
                    );
                ";
                createTableCommand.ExecuteNonQuery();
            }

            return _connection;
        }
    }
}
